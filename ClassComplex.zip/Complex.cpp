#include "Complex.h"

Complex:: Complex(const Complex &b)
{
	real = b.real;//��ʵ���鲿�ֱ𸳸�double
	vir = b.vir;
}
;

Complex Complex::conjugate()
{
	return Complex(real, -vir);//���干���;
}

Complex Complex::operator +(const Complex &b)
{
	return Complex(real+b.real, vir+b.vir);//���������������Ĳ�������
}

Complex Complex::operator +(const double &b)
{
	return Complex(real+b, vir);
}


Complex operator +(double a, Complex &b)
{
	return Complex(b.real+a, b.vir);
}

Complex Complex::operator -(const Complex &b)
{
	return Complex(real-b.real, vir-b.vir);
}

Complex Complex::operator -(const double &b)
{
	return Complex(real - b, vir);
}
Complex operator -(double a, Complex &b)
{
	return Complex(a - b.real, -b.vir);
}

Complex Complex::operator *(double b)
{
	return Complex(real*b, vir*b);
}

Complex Complex::operator *(const Complex &b)
{
	return Complex(real*b.real-vir*b.vir, real*b.vir+vir*b.real);
}

Complex operator *(double a, Complex &b)
{
	return Complex(a*b.real, a*b.vir);
}

Complex Complex::operator /(double b)
{
	return Complex(real/b, vir/b);
}

Complex Complex::operator /( Complex &b)
{
	Complex result= *this * b.conjugate();
	return Complex(result.real / (b.real*b.real + b.vir*b.vir), result.vir / (b.real*b.real + b.vir*b.vir));
}
Complex operator /(double a, Complex &b)
{
	Complex result = a*b.conjugate();
	return Complex(result.real / (b.real*b.real + b.vir*b.vir), result.vir / (b.real*b.real + b.vir*b.vir));
}

std::ostream &operator<<(std::ostream &out, const Complex &b)
{
	
	if (b.vir < 0)  out << b.real << b.vir << "i" << endl;//�ж��鲿������������������Ӻ�
	else
		if (b.vir == 1)  out << b.real << "+" << "i" << endl;//��һ���ж��鲿�Ƿ�Ϊ1�����������1��
		else
	       out << b.real << "+" << b.vir << "i" << endl;//���
	return out;
}