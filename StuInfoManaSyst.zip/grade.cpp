#include <stdexcept>
#include <vector>
#include "grade.h"
#include "median.h"
#include "Student_info.h"

using std::domain_error;
using std::vector;

//���غ���
double grade(double MidSco, double FinSco, double HomSco)
{
	return 0.2 * MidSco + 0.4 * FinSco + 0.4 * HomSco;
}


double grade(double MidSco, double FinSco, const vector<double>& hw)
{
	if (hw.size() == 0)
		throw domain_error("student has done no HomSco;");
	return grade(MidSco, FinSco, median(hw));
}

double grade(const Student_info& s)
{
	return grade(s.MidSco, s.FinSco, s.HomSco);
}