#ifndef GUARD_median_h
#define GUARD_median_h

#include<vector>

double median(vector<double>);

#endif