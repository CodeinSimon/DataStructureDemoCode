#include "Student_info.h"

using std::istream;
using std::vector;
bool compare(const Student_info& x, const Student_info& y)
{
	return x.StuName< y.StuName;
}

istream& read(istream& is, Student_info& s)
{
	cout << "StuName:" << endl;
	is >> s.StuName;
	cout << endl;
	cout << "MidSco gades:" << endl;
	is >> s.MidSco;
	cout << endl;
	cout << "FinSco grades:" << endl;
	is>> s.FinSco;
	cout << endl;
	cout << "HomSco grades:"<<endl;
	read_hw(is, s.HomSco);
	cout << endl;

	return is;
	

	
	
}

istream& read_hw(istream& in, vector<double>& hw)
{
	if (in) {
		hw.clear();
		double x;
		while (in >> x)
		{
			hw.push_back(x);
			char exit;//��ʾ�Ƿ����������Ϣ
			cout << "More HomSco grades? If not, enter 'q' to exit inputting, 'c' to continue." << endl;
			cin >> exit;
			if (exit == 'q') break;
			else
			{
				cout << "HomSco grades:" << endl;
				continue;
			}
		}
		in.clear();
	
	}
	return in;
}
