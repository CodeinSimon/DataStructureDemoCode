#pragma once

#include <iostream>
#include <string>
#include <cmath>

class Shape {
public:
	virtual std::string getType() const = 0;
	virtual double getArea() const = 0;
	virtual double getPerimeter() const = 0;
	Shape(){}
	~Shape(){}
};

class Triangle : public Shape
{
public:
	std::string getType() const { return "Triangle "; }

	Triangle(double a, double b, double c) : a_(a), b_(b), c_(c) {}

	double getArea() const
	{
		double s = (a_ + b_ + c_) / 2;
		double area = std::sqrt(s*(s - a_)*(s - b_)*(s - c_));
		return area;
	}
	double getPerimeter() const
	{
		return a_ + b_ + c_;
	}
	Triangle() {}
	~Triangle() {}
private:
	double a_, b_, c_;
};

class Rectangle : public Shape
{
public:
	std::string getType() const { return "Rectangle "; }

	Rectangle(double a, double b) : len_(a), wid_(b) {}

	double getArea() const
	{
		return len_ * wid_;
	}

	double getPerimeter() const
	{
		return 2 * (len_ + wid_);
	}
	Rectangle() {}
	~Rectangle() {}

private:
	double len_, wid_;

};

class Square : public Shape
{
public:
	std::string getType() const { return "Square "; }

	Square(double a) : h_(a) {}

	double getArea() const
	{
		return h_ * h_;
	}

	double getPerimeter() const
	{
		return 4 * h_;
	}
	Square() {}
	~Square() {}
private:
	double h_;

};
class Circle: public Shape
{
public:
	std::string getType()const { return "Circle "; }
	Circle(double a) : r_(a) {}
	double getArea() const
	{
		return 3.14159*r_*r_;
	}
	double getPerimeter()const
	{
		return 2 * 3.14159*r_;
	}
	Circle() {}
	~Circle() {}

private:
	double r_;

};
