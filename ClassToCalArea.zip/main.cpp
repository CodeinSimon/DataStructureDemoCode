#include "Shape.h"

using namespace std;

int main()
{
	Shape *point[5];
	Triangle tri(6, 8, 10);
	Rectangle rec(4, 5);
	Square sqr(4);
	Circle cir(5);

	point[0] = &tri;
	point[1] = &rec;
	point[2] = &sqr;
	point[3] = &cir;

	double area = 0;
	double perimeter = 0;
	for (int i = 0; i < 4; i++) {
		area += point[i]->getArea();
		perimeter += point[i]->getPerimeter();
		cout << point[i]->getType() << "area : " << point[i]->getArea() << "\n";
		cout << point[i]->getType() << "perimeter:" << point[i]->getPerimeter() << "\n";
	}
	cout << "total area: " << area << "\n";



	return 0;
}
